ESX = exports['es_extended']:getSharedObject()



local staffmode = false
RegisterCommand('staffon', function()
    ESX.TriggerServerCallback("permessi", function(checkpermessi)
        if checkpermessi == "superadmin" or checkpermessi == "admin" or checkpermessi == "mod" or checkpermessi == "helper" then 
            if not staffmode then
                staffmode = true
                local playerPed = GetPlayerPed(-1)
                Citizen.CreateThread(function()
                    local crdn = GetEntityCoords(playerPed)
                    propStaffMode = CreateObject(GetHashKey('staff'), crdn.x, crdn.y, crdn.z + 2.0,  true, true, true)
                    AttachEntityToEntity(propStaffMode, playerPed, GetPedBoneIndex(playerPed, 31086), 0.35, 0.0, 0.0, 180.0, 90.0, 0.0, 1, 1, 0, 0, 2, 1)
                end)
            else
                staffmode = false
                DeleteObject(propStaffMode)
            end
        else
            ESX.ShowNotification('Non hai i permessi')
        end
    end)
end, false)