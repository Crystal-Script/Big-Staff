fx_version 'adamant'
game 'gta5'

author 'Alga11'


client_script "cl-staff.lua"

server_script "sv-staff.lua"


data_file 'DLC_ITYP_REQUEST' 'stream/staff.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/staff.ydr'