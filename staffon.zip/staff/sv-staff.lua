ESX = exports['es_extended']:getSharedObject()

ESX.RegisterServerCallback("permessi", function(source, cb)
    local player = ESX.GetPlayerFromId(source)

    if player ~= nil then
        local pdpermessi = player.getGroup()

        if pdpermessi ~= nil then 
            cb(pdpermessi)
        else
            cb("user")
        end
    else
        cb("user")
    end
end)